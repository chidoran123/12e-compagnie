module.exports = {
    book: {
        assets: "./book",
        js: [
            "plugin.js"
        ]
    }
};
